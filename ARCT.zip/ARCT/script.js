    const cityGraph = {
        A: { B: { distance: 120, traffic: 'medium' }, D: { distance: 180, traffic: 'low' } },
        B: { A: { distance: 120, traffic: 'medium' }, C: { distance: 150, traffic: 'high' }, E: { distance: 200, traffic: 'low' } },
        C: { B: { distance: 150, traffic: 'high' }, F: { distance: 90, traffic: 'medium' } },
        D: { A: { distance: 180, traffic: 'low' }, E: { distance: 100, traffic: 'medium' } },
        E: { B: { distance: 200, traffic: 'low' }, D: { distance: 100, traffic: 'medium' }, F: { distance: 160, traffic: 'high' } },
        F: { C: { distance: 90, traffic: 'medium' }, E: { distance: 160, traffic: 'high' } }
    };

    const trafficData = {
        low: { color: 'green', timeMultiplier: 1, costMultiplier: 1.5 },
        medium: { color: 'yellow', timeMultiplier: 1.5, costMultiplier: 1.2 },
        high: { color: 'red', timeMultiplier: 2, costMultiplier: 1 }
    };

    const mapContainer = document.getElementById('mapContainer');
    const cityNodes = document.querySelectorAll('.city-node');
    const pathVisualization = document.getElementById('pathVisualization');
    const fromLocation = document.getElementById('fromLocation');
    const toLocation = document.getElementById('toLocation');
    const distance = document.getElementById('distance');
    const trafficLevel = document.getElementById('trafficLevel');
    const estimatedTime = document.getElementById('estimatedTime');
    const cost = document.getElementById('cost');
    const routeOptionsContainer = document.getElementById('routeOptionsContainer');
    const routeOptions = document.getElementById('routeOptions');
    const seatsContainer = document.getElementById('seatsContainer');
    const seatsGrid = document.getElementById('seatsGrid');
    const nextBtn = document.getElementById('nextBtn');
    const stepIndicators = document.querySelectorAll('.step');
    const loginModal = document.getElementById('loginModal');
    const paymentModal = document.getElementById('paymentModal');
    const successModal = document.getElementById('successModal');


    let selectedFrom = null;
    let selectedTo = null;
    let selectedRoute = null;
    let selectedSeat = null;
    let currentStep = 1;
    let userEmail = '';
    let isReturningUser = false;
    let bookingDetails = {};

    function init() {
        drawPaths();
        setupEventListeners();
        updateTrafficRandomly();
    }

    // draw path
    function drawPaths() {
        pathVisualization.innerHTML = '';
        
        for (const fromCity in cityGraph) {
            for (const toCity in cityGraph[fromCity]) {
                if (fromCity < toCity) {
                    drawPath(fromCity, toCity);
                }
            }
        }
    }

    function drawPath(fromCity, toCity) {
        const fromNode = document.querySelector(`.city-node[data-city="${fromCity}"]`);
        const toNode = document.querySelector(`.city-node[data-city="${toCity}"]`);
        
        if (!fromNode || !toNode) return;
        
        const fromRect = fromNode.getBoundingClientRect();
        const toRect = toNode.getBoundingClientRect();
        const containerRect = mapContainer.getBoundingClientRect();
        
        const fromX = fromRect.left + fromRect.width/2 - containerRect.left;
        const fromY = fromRect.top + fromRect.height/2 - containerRect.top;
        const toX = toRect.left + toRect.width/2 - containerRect.left;
        const toY = toRect.top + toRect.height/2 - containerRect.top;
        
        const length = Math.sqrt(Math.pow(toX - fromX, 2) + Math.pow(toY - fromY, 2));
        const angle = Math.atan2(toY - fromY, toX - fromX) * 180 / Math.PI;
        
        const path = document.createElement('div');
        path.className = 'path';
        path.style.width = `${length}px`;
        path.style.left = `${fromX}px`;
        path.style.top = `${fromY}px`;
        path.style.transform = `rotate(${angle}deg)`;
        path.dataset.from = fromCity;
        path.dataset.to = toCity;
        
        pathVisualization.appendChild(path);
        
        // Add traffic nodes
        addTrafficNodes(path, fromCity, toCity);
    }

    function addTrafficNodes(path, fromCity, toCity) {
        const pathData = cityGraph[fromCity][toCity];
        const traffic = pathData.traffic;
        const trafficCount = Math.floor(Math.random() * 3) + 2;
        
        for (let i = 0; i < trafficCount; i++) {
            const pos = Math.random() * 0.8 + 0.1;
            const node = document.createElement('div');
            node.className = `traffic-node ${traffic}`;
            
            const pathLength = parseFloat(path.style.width);
            const pathAngle = parseFloat(path.style.transform.match(/rotate\(([^)]+)deg\)/)[1]) * Math.PI / 180;
            
            const left = parseFloat(path.style.left) + pos * pathLength * Math.cos(pathAngle);
            const top = parseFloat(path.style.top) + pos * pathLength * Math.sin(pathAngle);
            
            node.style.left = `${left}px`;
            node.style.top = `${top}px`;
            
            pathVisualization.appendChild(node);
        }
    }

    // Update traffic levels randomly
    function updateTrafficRandomly() {
        for (const fromCity in cityGraph) {
            for (const toCity in cityGraph[fromCity]) {
                if (Math.random() < 0.2) {
                    const levels = ['low', 'medium', 'high'];
                    const newLevel = levels[Math.floor(Math.random() * levels.length)];
                    cityGraph[fromCity][toCity].traffic = newLevel;
                    cityGraph[toCity][fromCity].traffic = newLevel;
                }
            }
        }
        
        drawPaths();
        
        if (selectedRoute) {
            updateRouteInfo(selectedRoute);
        }

        setTimeout(updateTrafficRandomly, 600 + Math.random() * 5000);
    }

    function setupEventListeners() {

        cityNodes.forEach(node => {
            node.addEventListener('click', () => {
                const city = node.dataset.city;
                
                if (!selectedFrom) {
                    selectedFrom = city;
                    node.classList.add('selected');
                    fromLocation.textContent = city;

                    if (selectedTo) {
                        document.querySelector(`.city-node[data-city="${selectedTo}"]`).classList.remove('selected');
                        selectedTo = null;
                        toLocation.textContent = 'Not selected';
                    }
                } else if (!selectedTo && city !== selectedFrom) {
  
                    selectedTo = city;
                    node.classList.add('selected');
                    toLocation.textContent = city;
                    
                    findRouteOptions(selectedFrom, selectedTo);
                } else if (city === selectedFrom) {
                    selectedFrom = null;
                    node.classList.remove('selected');
                    fromLocation.textContent = 'Not selected';
                    
                    routeOptionsContainer.style.display = 'none';
                    seatsContainer.style.display = 'none';
                    nextBtn.disabled = true;
                } else if (city === selectedTo) {
                    selectedTo = null;
                    node.classList.remove('selected');
                    toLocation.textContent = 'Not selected';

                    routeOptionsContainer.style.display = 'none';
                    seatsContainer.style.display = 'none';
                    nextBtn.disabled = true;
                }
            });
        });
        
        // Next button
        nextBtn.addEventListener('click', () => {
            if (currentStep === 1 && selectedRoute) {

                currentStep = 2;
                updateStepIndicator();
                seatsContainer.style.display = 'block';
                nextBtn.textContent = 'Next';
            } else if (currentStep === 2 && selectedSeat) {

                currentStep = 3;
                updateStepIndicator();
                showLoginModal();
            }
        });
        
        // Seat selection
        seatsGrid.addEventListener('click', (e) => {
            if (e.target.classList.contains('seat') && !e.target.classList.contains('booked')) {
                if (selectedSeat) {
                    document.querySelector(`.seat[data-seat="${selectedSeat}"]`).classList.remove('selected');
                }
                
                selectedSeat = e.target.dataset.seat;
                e.target.classList.add('selected');
                nextBtn.disabled = false;
            }
        });

        document.querySelector('.close-modal').addEventListener('click', () => {
            loginModal.classList.remove('active');
        });
        
        // Login button
        document.getElementById('loginBtn').addEventListener('click', () => {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            isReturningUser = document.getElementById('returningUser').checked;
            
            if (email && password) {
                userEmail = email;
                
                loginModal.classList.remove('active');
                currentStep = 4;
                updateStepIndicator();
                showPaymentModal();
            } else {
                alert('Please enter both email and password');
            }
        });
        
        document.querySelectorAll('#paymentModal .close-modal')[0].addEventListener('click', () => {
            paymentModal.classList.remove('active');
        });
        
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', () => {
                document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
                option.classList.add('selected');
            });
        });
        
        document.getElementById('confirmPaymentBtn').addEventListener('click', () => {
            const trxId = document.getElementById('trxId').value;
            
            if (!trxId) {
                alert('Please enter a transaction ID');
                return;
            }
            
            paymentModal.classList.remove('active');
            currentStep = 5;
            updateStepIndicator();
            showSuccessModal();
            
            bookingDetails = {
                from: selectedFrom,
                to: selectedTo,
                route: selectedRoute,
                seat: selectedSeat,
                email: userEmail,
                isReturningUser: isReturningUser,
                trxId: trxId,
                date: new Date().toLocaleString(),
                cost: calculateTotalCost()
            };
            
            console.log('Booking completed:', bookingDetails);
            //throw to backend
        });
        
        // Download receipt
        document.getElementById('downloadBtn').addEventListener('click', () => {
            alert('Receipt downloaded! (This would generate a PDF in a real app)');
            console.log('Receipt content:', generateReceiptContent());
        });
    }

    function findRouteOptions(from, to) {
        const routes = [];
        const queue = [[from]];
        
        while (queue.length > 0) {
            const path = queue.shift();
            const lastNode = path[path.length - 1];
            
            if (lastNode === to) {
                routes.push(path);
                continue;
            }
            
            for (const neighbor in cityGraph[lastNode]) {
                if (!path.includes(neighbor)) {
                    queue.push([...path, neighbor]);
                }
            }
        }
        
        const displayedRoutes = routes.slice(0, 3);

        displayRouteOptions(displayedRoutes);
    }

    function displayRouteOptions(routes) {
        routeOptions.innerHTML = '';
        
        routes.forEach((route, index) => {
            const routeOption = document.createElement('div');
            routeOption.className = 'route-option';
            routeOption.dataset.index = index;
            
            const { totalDistance, worstTraffic } = calculateRouteStats(route);
            const { time, cost } = calculateTimeAndCost(route);
            
            const trafficClass = worstTraffic || 'medium';
            const trafficLabel = worstTraffic ? worstTraffic.charAt(0).toUpperCase() + worstTraffic.slice(1) : 'Medium';
            
            routeOption.innerHTML = `
                <div class="option-header">
                    <span class="option-title">Option ${index + 1}</span>
                    <span class="option-traffic ${trafficClass}">${trafficLabel} Traffic</span>
                </div>
                <div class="option-details">
                    <span>${route.join(' → ')}</span>
                    <span>${totalDistance} km</span>
                </div>
                <div class="option-details">
                    <span>${time} Min</span>
                    <span>${cost} Taka</span>
                </div>
            `;
            
            routeOption.addEventListener('click', () => {
                document.querySelectorAll('.route-option').forEach(opt => opt.classList.remove('selected'));
                routeOption.classList.add('selected');
                selectedRoute = route;
                updateRouteInfo(route);
                nextBtn.disabled = false;
            });
            
            routeOptions.appendChild(routeOption);
        });
        
        routeOptionsContainer.style.display = 'block';
    }

    function calculateRouteStats(route) {
        let totalDistance = 0;
        let worstTraffic = null;
        
        for (let i = 0; i < route.length - 1; i++) {
            const from = route[i];
            const to = route[i + 1];
            const pathData = cityGraph[from][to];
            
            totalDistance += pathData.distance;
            
            if (!worstTraffic || 
                trafficData[pathData.traffic].timeMultiplier > trafficData[worstTraffic].timeMultiplier) {
                worstTraffic = pathData.traffic;
            }
        }
        
        return { totalDistance, worstTraffic };
    }

    function calculateTimeAndCost(route) {
        const baseSpeed = 60;
        const baseCostPerKm = 2;
        
        let totalTime = 0;
        let totalCost = 0;
        
        for (let i = 0; i < route.length - 1; i++) {
            const from = route[i];
            const to = route[i + 1];
            const pathData = cityGraph[from][to];

            const timeMultiplier = trafficData[pathData.traffic].timeMultiplier;
            const segmentTime = (pathData.distance / baseSpeed) * 60 * timeMultiplier;
            totalTime += segmentTime;
            
            const costMultiplier = trafficData[pathData.traffic].costMultiplier;
            const segmentCost = pathData.distance * baseCostPerKm * costMultiplier;
            totalCost += segmentCost;
        }
        
        return {
            time: Math.round(totalTime),
            cost: Math.round(totalCost)
        };
    }

    function updateRouteInfo(route) {
        const { totalDistance, worstTraffic } = calculateRouteStats(route);
        const { time, cost } = calculateTimeAndCost(route);
        
        distance.textContent = `${totalDistance} km`;
        trafficLevel.textContent = worstTraffic ? worstTraffic.charAt(0).toUpperCase() + worstTraffic.slice(1) : 'Medium';
        trafficLevel.style.color = trafficData[worstTraffic].color;
        estimatedTime.textContent = `${time} Min`;
        this.cost.textContent = `${cost} Taka`;
    }

    //discount
    function calculateTotalCost() {
        if (!selectedRoute) return 0;
        
        const { cost } = calculateTimeAndCost(selectedRoute);
        let total = cost;
        
        if (isReturningUser) {
            total *= 0.9;
        }
        
        return Math.round(total);
    }

    function updateStepIndicator() {
        stepIndicators.forEach((step, index) => {
            step.classList.remove('active', 'completed');
            
            if (index + 1 === currentStep) {
                step.classList.add('active');
            } else if (index + 1 < currentStep) {
                step.classList.add('completed');
            }
        });

        if (currentStep === 1) {
            nextBtn.textContent = 'Next: Choose Seat';
        } else if (currentStep === 2) {
            nextBtn.textContent = 'Next: Login';
        }
    }

    function showLoginModal() {
        document.getElementById('email').value = '';
        document.getElementById('password').value = '';
        document.getElementById('returningUser').checked = false;
        loginModal.classList.add('active');
    }

    function showPaymentModal() {
        document.getElementById('trxId').value = '';
        document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
        
        if (isReturningUser) {
            document.getElementById('discountNotice').style.display = 'block';
        } else {
            document.getElementById('discountNotice').style.display = 'none';
        }
        
        paymentModal.classList.add('active');
    }


    function showSuccessModal() {
        successModal.classList.add('active');
    }

    function generateReceiptContent() {
        return `
            AI Route Craft Travel - Booking Receipt
            --------------------------------------
            
            Booking Date: ${bookingDetails.date}
            Email: ${bookingDetails.email}
            
            Journey Details:
            From: ${bookingDetails.from}
            To: ${bookingDetails.to}
            Route: ${bookingDetails.route.join(' → ')}
            Seat: ${bookingDetails.seat}
            
            Payment Details:
            Amount: ${bookingDetails.cost} Taka
            ${isReturningUser ? '(10% returning customer discount applied)' : ''}
            Transaction ID: ${bookingDetails.trxId}
            
            Thank you for traveling with us!
        `;
    }

    init();

async function submitPayment() {
  const paymentData = {
    user_id: 123,
    from: "A",
    to: "C",
    route: ["A", "B", "C"],
    seat: "4A",
    amount: 500,
    trx_id: "BKASH123456"
  };

  try {
    const response = await fetch('http://127.0.0.1:5000/api/save_booking', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(paymentData)
    });
    
    const result = await response.json();
    console.log("API Response:", result);
  } catch (error) {
    console.error("Error:", error);
  }
}