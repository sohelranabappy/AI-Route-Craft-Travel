import mysql.connector
import heapq
from werkzeug.security import generate_password_hash, check_password_hash
import time
import json

class Node:
    def __init__(self, city, g_cost=0, h_cost=0):
        self.city = city
        self.g_cost = g_cost
        self.h_cost = h_cost
        self.f_cost = g_cost + h_cost
        self.parent = None

    def __lt__(self, other):
        return self.f_cost < other.f_cost

class RouteCraftSystem:
    def __init__(self):
        self.db_config = {
            'host': 'localhost',
            'user': 'root',
            'password': '',  
            'database': 'route_craft_db'
        }
        
        if not self.test_db_connection():
            raise Exception("Failed to connect to database")
        self.initialize_database()
        
        self.current_user = None

    # Database Functions
    def test_db_connection(self):
        """Test database connection"""
        try:
            conn = mysql.connector.connect(**self.db_config)
            cursor = conn.cursor()
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print("Database connection successful!")
            print(f"Available tables: {tables}")
            cursor.close()
            conn.close()
            return True
        except mysql.connector.Error as err:
            print(f"Database connection failed: {err}")
            return False

    def db_execute(self, query, params=None, fetch=False):
        """Execute database query with error handling"""
        try:
            conn = mysql.connector.connect(**self.db_config)
            cursor = conn.cursor(dictionary=True)
            
            cursor.execute(query, params or ())
            if fetch:
                result = cursor.fetchall()
            else:
                result = True
            
            conn.commit()
            return result
        except mysql.connector.Error as err:
            print(f"Database error: {err}")
            return False
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()

    def initialize_database(self):
        """Initialize database tables if they don't exist"""
        # Users table
        self.db_execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            is_returning BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)
        
        # Bookings table
        self.db_execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            from_city VARCHAR(10) NOT NULL,
            to_city VARCHAR(10) NOT NULL,
            route TEXT NOT NULL,
            seat VARCHAR(10) NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            trx_id VARCHAR(50),
            booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
        """)
        
        # Transactions table
        self.db_execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            trx_id VARCHAR(50) NOT NULL UNIQUE,
            amount DECIMAL(10, 2) NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            user_id INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            verified_at TIMESTAMP NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
        """)

    # A* Algorithm Core
    def a_star(self, graph, start, end):
        open_set = []
        closed_set = set()
        
        start_node = Node(start, 0, self.heuristic(start, end))
        heapq.heappush(open_set, start_node)
        
        while open_set:
            current_node = heapq.heappop(open_set)
            
            if current_node.city == end:
                return self.reconstruct_path(current_node)
                
            closed_set.add(current_node.city)
            
            for neighbor, data in graph[current_node.city].items():
                if neighbor in closed_set:
                    continue
                    
                g_cost = current_node.g_cost + data['distance'] * data['traffic_multiplier']
                h_cost = self.heuristic(neighbor, end)
                f_cost = g_cost + h_cost
                
                neighbor_node = None
                for node in open_set:
                    if node.city == neighbor:
                        neighbor_node = node
                        break
                
                if neighbor_node is None:
                    neighbor_node = Node(neighbor, g_cost, h_cost)
                    neighbor_node.parent = current_node
                    heapq.heappush(open_set, neighbor_node)
                elif f_cost < neighbor_node.f_cost:
                    neighbor_node.g_cost = g_cost
                    neighbor_node.h_cost = h_cost
                    neighbor_node.f_cost = f_cost
                    neighbor_node.parent = current_node
                    heapq.heapify(open_set)
        
        return []

    def heuristic(self, node, end):
        node_positions = {
            'A': (0, 0), 'B': (1, 0), 'C': (2, 0),
            'D': (0, 1), 'E': (1, 1), 'F': (2, 1)
        }
        x1, y1 = node_positions[node]
        x2, y2 = node_positions[end]
        return abs(x1 - x2) + abs(y1 - y2)

    def reconstruct_path(self, node):
        path = []
        current = node
        while current:
            path.append(current.city)
            current = current.parent
        return path[::-1]

    def get_current_traffic_graph(self):
        """Fetch traffic data with real-time simulation"""
        base_graph = {
            'A': {'B': 120, 'D': 180},
            'B': {'A': 120, 'C': 150, 'E': 200},
            'C': {'B': 150, 'F': 90},
            'D': {'A': 180, 'E': 100},
            'E': {'B': 200, 'D': 100, 'F': 160},
            'F': {'C': 90, 'E': 160}
        }
        
        current_minute = int(time.time() / 300) % 3
        
        traffic_multipliers = {
            0: {'low': 1.0, 'medium': 1.5, 'high': 2.0},  # Morning
            1: {'low': 1.2, 'medium': 1.8, 'high': 2.5},  # Afternoon
            2: {'low': 0.8, 'medium': 1.3, 'high': 1.8}   # Evening
        }
        
        current_traffic = traffic_multipliers[current_minute]
        
        graph = {}
        for node, neighbors in base_graph.items():
            graph[node] = {}
            for neighbor, distance in neighbors.items():
                traffic_level = ['low', 'medium', 'high'][hash(f"{node}{neighbor}{current_minute}") % 3]
                graph[node][neighbor] = {
                    'distance': distance,
                    'traffic_multiplier': current_traffic[traffic_level],
                    'traffic_level': traffic_level
                }
        
        return graph
    # User Authentication
    def register(self, email, password):
        """User registration"""
        if not email or not password:
            return {'success': False, 'message': 'Email and password are required'}      
        # Check if email exists
        existing = self.db_execute(
            "SELECT id FROM users WHERE email = %s", 
            (email,), 
            fetch=True
        )      
        if existing:
            return {'success': False, 'message': 'Email already registered'}
        hashed_password = generate_password_hash(password)

        self.db_execute(
            "INSERT INTO users (email, password) VALUES (%s, %s)",
            (email, hashed_password)
        )
        return {'success': True, 'message': 'Registration successful'}

    def login(self, email, password):
        """User login"""
        if not email or not password:
            return {'success': False, 'message': 'Email and password are required'}
        
        # Get user from database
        user = self.db_execute(
            "SELECT * FROM users WHERE email = %s", 
            (email,), 
            fetch=True
        )
        if user and check_password_hash(user[0]['password'], password):
            self.current_user = user[0]
            return {
                'success': True,
                'is_returning': bool(user[0]['is_returning']),
                'user_id': user[0]['id'],
                'message': 'Login successful'
            }
        return {'success': False, 'message': 'Invalid credentials'}

    def logout(self):
        """Logout current user"""
        self.current_user = None
        return {'success': True, 'message': 'Logged out successfully'}

    # Booking Logic
    def find_routes(self, start, end):
        """Find optimal routes between cities"""
        if not start or not end:
            return {'success': False, 'error': 'Missing from or to parameters'}
        
        graph = self.get_current_traffic_graph()
        optimal_route = self.a_star(graph, start, end)
        
        if not optimal_route:
            return {'success': False, 'error': 'No route found'}

        total_distance = 0
        total_time = 0
        total_cost = 0
        traffic_info = []
        
        for i in range(len(optimal_route) - 1):
            current = optimal_route[i]
            next_node = optimal_route[i + 1]
            segment = graph[current][next_node]
            
            total_distance += segment['distance']
            segment_time = segment['distance'] * segment['traffic_multiplier'] / 2
            total_time += segment_time
            segment_cost = segment['distance'] * 1.5 * segment['traffic_multiplier']
            total_cost += segment_cost
            
            traffic_info.append({
                'from': current,
                'to': next_node,
                'distance': segment['distance'],
                'traffic_level': segment['traffic_level'],
                'time': round(segment_time, 2),
                'cost': round(segment_cost, 2)
            })
        
        # Generate alternative routes
        all_routes = []
        if optimal_route:
            all_routes.append({
                'route': optimal_route,
                'distance': round(total_distance, 2),
                'time': round(total_time, 2),
                'cost': round(total_cost, 2),
                'traffic_info': traffic_info,
                'is_optimal': True
            })

            for alt in range(1, 3):
                if len(optimal_route) > 2:
                    alt_route = [optimal_route[0], optimal_route[-1]]
                    all_routes.append({
                        'route': alt_route,
                        'distance': graph[alt_route[0]][alt_route[1]]['distance'],
                        'time': round(graph[alt_route[0]][alt_route[1]]['distance'] * 
                                     graph[alt_route[0]][alt_route[1]]['traffic_multiplier'] / 2, 2),
                        'cost': round(graph[alt_route[0]][alt_route[1]]['distance'] * 1.5 * 
                                     graph[alt_route[0]][alt_route[1]]['traffic_multiplier'], 2),
                        'traffic_info': [{
                            'from': alt_route[0],
                            'to': alt_route[1],
                            'distance': graph[alt_route[0]][alt_route[1]]['distance'],
                            'traffic_level': graph[alt_route[0]][alt_route[1]]['traffic_level'],
                            'time': round(graph[alt_route[0]][alt_route[1]]['distance'] * 
                                         graph[alt_route[0]][alt_route[1]]['traffic_multiplier'] / 2, 2),
                            'cost': round(graph[alt_route[0]][alt_route[1]]['distance'] * 1.5 * 
                                         graph[alt_route[0]][alt_route[1]]['traffic_multiplier'], 2)
                        }],
                        'is_optimal': False
                    })
        
        return {'success': True, 'routes': all_routes}

    def save_booking(self, from_city, to_city, route, seat, amount, trx_id):
        """Save booking to database"""
        if not self.current_user:
            return {'success': False, 'message': 'Not authenticated'}
        
        required_fields = [from_city, to_city, route, seat, amount, trx_id]
        if not all(required_fields):
            return {'success': False, 'message': 'Missing required fields'}
        
        try:
            self.db_execute(
                "INSERT INTO bookings (user_id, from_city, to_city, route, seat, amount, trx_id) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (self.current_user['id'], from_city, to_city, 
                 ','.join(route), seat, amount, trx_id)
            )
            
            # Mark user as returning
            self.db_execute(
                "UPDATE users SET is_returning = TRUE WHERE id = %s",
                (self.current_user['id'],)
            )
            
            # Record transaction
            self.db_execute(
                "INSERT INTO transactions (trx_id, amount, status, user_id, verified_at) "
                "VALUES (%s, %s, 'completed', %s, NOW())",
                (trx_id, amount, self.current_user['id'])
            )     
            return {
                'success': True,
                'message': 'Booking saved successfully'
            }
        except Exception as e:
            return {
                'success': False,
                'message': 'Database error',
                'error': str(e)
            }

    def verify_payment(self, trx_id):
        """Verify payment transaction"""
        if not trx_id:
            return {'success': False, 'message': 'Transaction ID is required'}
        
        transaction = self.db_execute(
            "SELECT * FROM transactions WHERE trx_id = %s AND status = 'completed'",
            (trx_id,),
            fetch=True
        )
        
        if transaction:
            return {
                'success': True,
                'verified': True,
                'amount': float(transaction[0]['amount']),
                'verified_at': transaction[0]['verified_at'].isoformat() if transaction[0]['verified_at'] else None
            }
        else:
            return {
                'success': False,
                'verified': False,
                'message': 'Transaction not found or not completed'
            }
if __name__ == '__main__':
    system = RouteCraftSystem()
    print("\n=== Registration ===")
    print(system.register("test@example.com", "password123"))
    
    print("\n=== Login ===")
    print(system.login("test@example.com", "password123"))
    
    print("\n=== Find Routes (A to F) ===")
    routes = system.find_routes("A", "F")
    print(json.dumps(routes, indent=2))
    
    if routes['success'] and len(routes['routes']) > 0:
        print("\n=== Save Booking ===")
        booking = system.save_booking(
            from_city="A",
            to_city="F",
            route=routes['routes'][0]['route'],
            seat="5",
            amount=routes['routes'][0]['cost'],
            trx_id="QA1234567"
        )
        print(booking)
        
        print("\n=== Verify Payment ===")
        print(system.verify_payment("QA1234567"))
    
    print("\n=== Logout ===")
    print(system.logout())