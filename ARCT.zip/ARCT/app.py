from flask import Flask, request, jsonify, render_template
from route_craft import RouteCraftSystem
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

system = RouteCraftSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/find_routes', methods=['POST'])
def find_routes():
    data = request.get_json()
    start = data.get('from')
    end = data.get('to')
    result = system.find_routes(start, end)
    return jsonify(result)

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    result = system.login(email, password)
    return jsonify(result)

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    result = system.register(email, password)
    return jsonify(result)

@app.route('/api/save_booking', methods=['POST'])
def save_booking():
    data = request.get_json()
    result = system.save_booking(
        from_city=data['from'],
        to_city=data['to'],
        route=data['route'],
        seat=data['seat'],
        amount=data['amount'],
        trx_id=data['trx_id']
    )
    return jsonify(result)

@app.route('/api/verify_payment', methods=['POST'])
def verify_payment():
    data = request.get_json()
    trx_id = data.get('trx_id')
    result = system.verify_payment(trx_id)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)